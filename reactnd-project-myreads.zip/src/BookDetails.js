import React, { Component } from 'react';
//TODO: open book details when clicking on the thumbnail
class BookDetails extends Component {
  render() {
    return <div></div>;
  }
}
export default BookDetails